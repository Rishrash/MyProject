package com.cg.lpa.service;

/**
 * @author rabbhi modified on 03/09/2018
 * 
 */
import java.util.ArrayList;

import com.cg.lpa.bean.ApprovedLoanBean;
import com.cg.lpa.bean.LoanApplicationBean;
import com.cg.lpa.bean.LoanProgramOfferedBean;
import com.cg.lpa.exception.LoanProcessingException;

public interface IAdminService {
	/*
	 * TODO : Add New Loan Program. TODO : Delete Loan Program. TODO : View Loan
	 * Application For Specific Staus TODO: View Approved Loan.
	 */
	public boolean addLoanProgram(LoanProgramOfferedBean loanProgram) throws LoanProcessingException;

	public boolean deleteLoanProgram(String loanProgram) throws LoanProcessingException;

	public ArrayList<LoanApplicationBean> viewLoanApplicationForSpecificStatus(String status)
			throws LoanProcessingException;

	public ArrayList<ApprovedLoanBean> viewApprovedLoan() throws LoanProcessingException;

}
