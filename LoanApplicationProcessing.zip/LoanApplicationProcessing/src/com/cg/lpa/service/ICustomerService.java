package com.cg.lpa.service;

/**
 * @author rabbhi modified on 02/09/2018
 * 
 */
import com.cg.lpa.bean.CustomerDetailsBean;
import com.cg.lpa.bean.LoanApplicationBean;
import com.cg.lpa.exception.LoanProcessingException;

public interface ICustomerService {

	/*
	 * TODO : Apply For a Loan Program. TODO : Fill Customer Details TODO : View
	 * Application Status by entering application id. TODO : Delete Loan Application
	 */

	public boolean applyLoan(LoanApplicationBean loanapplication) throws LoanProcessingException;

	public boolean fillCustomerDetails(CustomerDetailsBean customer) throws LoanProcessingException;

	public String viewApplicationStatus(int applicationID) throws LoanProcessingException;

	public boolean deleteLoanApplication(int applicationId) throws LoanProcessingException;

}
