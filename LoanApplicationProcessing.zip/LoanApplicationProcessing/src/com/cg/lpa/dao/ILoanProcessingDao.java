package com.cg.lpa.dao;

/**
 * @author rabbhi modified on 03/09/2018
 * 
 */
import java.util.ArrayList;

import com.cg.lpa.bean.LoanProgramOfferedBean;
import com.cg.lpa.exception.LoanProcessingException;

public interface ILoanProcessingDao {

	public int loginUser(String userId, String password) throws LoanProcessingException;

	public ArrayList<LoanProgramOfferedBean> viewLoanProgramsOffered() throws LoanProcessingException;

}
