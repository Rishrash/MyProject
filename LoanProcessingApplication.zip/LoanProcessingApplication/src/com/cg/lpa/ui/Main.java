package com.cg.lpa.ui;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.lpa.bean.ApprovedLoanBean;
import com.cg.lpa.bean.CustomerDetailsBean;
import com.cg.lpa.bean.LoanApplicationBean;
import com.cg.lpa.bean.LoanProgramOfferedBean;
import com.cg.lpa.service.AdminServiceImpl;
import com.cg.lpa.service.CustomerServiceImpl;
import com.cg.lpa.service.IAdminService;
import com.cg.lpa.service.ICustomerService;
import com.cg.lpa.service.ILoanApprovalDeptService;
import com.cg.lpa.service.ILoanProcessingService;
import com.cg.lpa.service.LoanApprovalDeptServiceImpl;
import com.cg.lpa.service.LoanProcessingServiceImpl;
import com.cg.lpa.test.LoanProcessingException;

public class Main {
	private static Scanner input;
	private static Scanner inputString;

	static ILoanProcessingService loanProcessingService = null;
	static ICustomerService customerService = null;
	static ILoanApprovalDeptService ladService = null;
	static IAdminService adminService = null;
	static Logger logg = Logger.getRootLogger();

	// MAIN METHOD
	public static void main(String[] args) throws LoanProcessingException {

		input = new Scanner(System.in);
		inputString = new Scanner(System.in);

		startTheProgram();
	}

	// START METHOD
	private static void startTheProgram() throws LoanProcessingException {

		System.out.println("Welcome To Loan Processing Application\n\n");
		System.out.println("Select your role from below :");
		System.out.println("1. Enter as a Customer");
		System.out
				.println("2. Login as Member Of Approval Department or Admin");
		System.out.println("3. Exit");

		String userInput = input.next();

		switch (userInput) {
		case "1":
			enteredAsCustomer();
			break;
		case "2":
			loginUser();
			break;
		case "3":
			System.out.println("Have a Nice Day :-) ");
			System.exit(0);
		default:
			System.out.println("Invalid choice");
		}
		startTheProgram();
	}

	// LOGIN METHOD
	private static void loginUser() throws LoanProcessingException {
		loanProcessingService = new LoanProcessingServiceImpl();
		input = new Scanner(System.in);
		System.out.print("UserId : ");
		String userId = input.next();
		while (!loanProcessingService.isValidUserId(userId)) {
			System.err
					.println("UserId Should contain only numbers and should be of length 4 ");
			System.out.print("UserId : ");
			userId = input.next();
		}
		System.out.print("Password : ");
		String password = input.next();
		while (!loanProcessingService.isValidPassword(password)) {
			System.err
					.println("Password should be less than 10 characters and should not contain spaces");
			System.out.print("Password : ");
			password = input.next();
		}

		try {
			if (loanProcessingService.loginUser(userId, password) == 0) {

				// Enter As Member of Loan Approval Board
				enteredAsMemberOfBoard();

			} else if (loanProcessingService.loginUser(userId, password) == 1) {

				// Enter As Admin
				enteredAsAdmin();

			} else {

				// Incorrect Password
				System.out.println("UserID or Password is wrong");

			}
		} catch (LoanProcessingException e) {

			throw new LoanProcessingException("problem : " + e.getMessage());
		}

	}

	// ================================================================
	// = 1. When User has Entered As a Customer
	// ================================================================

	private static void enteredAsCustomer() {

		System.out
				.println("############################ Welcome Customer ###############################");
		System.out
				.println("#                                                                           #");
		System.out
				.println("#        ---  Select Options from Given menu  ---                           #");
		System.out
				.println("#          1. View all Loan Programs                                        #");
		System.out
				.println("#          2. Apply for a new loan                                          #");
		System.out
				.println("#          3. View Application status of your Loan Application              #");
		System.out
				.println("#          4. Previous Page                                                 #");
		System.out
				.println("#          5. Exit			                                    #");
		System.out
				.println("#                                                                           #");
		System.out
				.println("#############################################################################");
		try {
			loanProcessingService = new LoanProcessingServiceImpl();
			customerService = new CustomerServiceImpl();
			String customerChoice = input.next();
			switch (customerChoice) {

			// View loan Programs
			case "1":
				if (displayLoanPrograms()) {
					System.out.println("No Record Found");
				}
				break;
			case "2":
				System.out
						.println("###########################################");
				System.out
						.println("#        Fill Loan Application Form:      #");
				System.out
						.println("###########################################");

				// Input Loan Program Name
				System.out.println("Enter Loan Program Name");
				String loanProgram = input.next();
				while (!loanProcessingService.isValidString(loanProgram)) {
					System.err
							.println("Should contain a minimum of 5 Characters");
					System.out.println("Enter Loan Program Name");
					loanProgram = input.next();
				}

				// Input Loan Amount
				System.out.println("Enter Loan Amount");
				String loanAmountString = input.next();
				while (!loanProcessingService.isValidDouble(loanAmountString)) {
					System.err.println("Not a valid amount");
					System.out.println("Enter Loan Amount");
					loanAmountString = input.next();
				}
				double loanAmount = Double.parseDouble(loanAmountString);

				// Input Property Address
				System.out.println("Enter your Property Address");
				String propertyAddress = inputString.nextLine();
				while (!loanProcessingService.isValidAddress(propertyAddress)) {
					System.err.println("Not a valid Property Address");
					System.out.println("Enter your Property Address");
					propertyAddress = inputString.nextLine();
				}

				// Input Annual Family Income
				System.out.println("Enter Annual Family Income");
				String annualFamilyIncomeString = input.next();
				while (!loanProcessingService
						.isValidDouble(annualFamilyIncomeString)) {
					System.err.println("Not a valid amount");
					System.out.println("Enter Annual Family Income");
					annualFamilyIncomeString = input.next();

				}

				double annualFamilyIncome = Double
						.parseDouble(annualFamilyIncomeString);

				// Input Documents Proof to be Displayed
				System.out.println("Docs Proof to be diplayed");
				String docsProof = inputString.nextLine();
				while (!loanProcessingService.isValidDocsProofString(docsProof)) {
					System.err
							.println("Docs Proof Details should not be more than 50 characters");
					System.out.println("Docs Proof to be diplayed");
					docsProof = inputString.nextLine();
				}

				// Input Guarantee Cover Details
				System.out.println("Guarantee Cover Details ");
				String guaranteeCover = inputString.nextLine();
				while (!loanProcessingService
						.isValidGauranteeCoverString(guaranteeCover)) {
					System.err
							.println("Guarantee Cover Details  should not be more than 20 characters");
					System.out.println("Guarantee Cover Details ");
					guaranteeCover = inputString.nextLine();
				}

				// Input Market Value Of Guarantee Cover
				System.out.println("Market Value Of your Guarantee Cover");
				String marktValOfCoverString = input.next();
				while (!loanProcessingService
						.isValidDouble(marktValOfCoverString)) {
					System.err.println("Not a valid amount");
					System.out.println("Market Value Of your Guarantee Cover");
					marktValOfCoverString = input.next();
				}
				double marktValOfCover = Double
						.parseDouble(marktValOfCoverString);

				// Saving Details In Loan Application Bean Class
				LoanApplicationBean loanApplication = new LoanApplicationBean(
						loanProgram, loanAmount, propertyAddress,
						annualFamilyIncome, docsProof, guaranteeCover,
						marktValOfCover);
				// Inserting Data In Loan Application Table
				boolean status = customerService.applyLoan(loanApplication);

				// Checking If Data is Inserted Successfully
				if (status == true) {
					logg.info("Data is successfully inserted in Loan Application Form");
					int applicationId = loanApplication.getApplicationId();
					System.out
							.println("Application Id for your Application is : "
									+ applicationId);
					System.out.println("/n/n");
					System.out
							.println("###########################################");
					System.out
							.println("#       Fill your Personal Details        #");
					System.out
							.println("###########################################");

					// Enter Applicant Name
					System.out.println("Enter your Full Name");
					String applicantName = inputString.nextLine();
					while (!loanProcessingService
							.isValidApplicantName(applicantName)) {
						System.err
								.println("Name should contain not more than 20 characters");
						System.out.println("Enter your Full Name");
						applicantName = inputString.nextLine();
					}

					// Input Date Of Birth
					System.out
							.println("Input Date Of Birth in dd-MMM-yyyy Format");
					String dateOfBirth = input.next();
					while (!loanProcessingService.isValidDate(dateOfBirth)) {
						System.err.println("Invalid Date Format");
						System.out
								.println("Input Date Of Birth in dd-MMM-yyyy Format");
						dateOfBirth = input.next();

					}

					// Input Maritial Status
					System.out.println("Maritial Status");
					String maritalStatus = input.next();
					while (!loanProcessingService
							.isValidMaritalStatus(maritalStatus)) {
						System.err.println("Invalid Maritial Status");
						System.out.println("Maritial Status");
						maritalStatus = input.next();

					}

					// Input Phone Number
					System.out.println("Enter your Phone Number");
					String phoneNumberString = input.next();
					while (!loanProcessingService
							.isValidPhoneNumber(phoneNumberString)) {
						System.err
								.println("Phone Number should contain 10 digits");
						System.out.println("Enter your Phone Number");
						phoneNumberString = input.next();
					}
					long phoneNumber = Long.parseLong(phoneNumberString);

					// Input Mobile Number
					System.out.println("Enter your Mobile Number");
					String mobileNumberString = input.next();
					while (!loanProcessingService
							.isValidPhoneNumber(mobileNumberString)) {
						System.err
								.println("Phone Number should contain 10 digits");
					}
					long mobileNumber = Long.parseLong(mobileNumberString);

					// Input Dependents Count
					System.out.println("What is your Dependants Count ?");
					String dependentsCountString = input.next();
					while (!loanProcessingService
							.isValidNumber(dependentsCountString)) {
						System.err.println("Enter a valid Number");
						System.out.println("What is your Dependants Count ?");
						dependentsCountString = input.next();

					}
					int dependentsCount = Integer
							.parseInt(dependentsCountString);

					// Input Email Id
					System.out.println("Enter your Email ID");
					String emailId = input.next();
					while (!loanProcessingService.isValidEmailId(emailId)) {
						System.err.println("Not a Valid emailId");
						System.out.println("Enter your Email ID");
						emailId = input.next();
					}
					CustomerDetailsBean customerDetails = new CustomerDetailsBean(
							applicationId, applicantName, dateOfBirth,
							maritalStatus, phoneNumber, mobileNumber,
							dependentsCount, emailId);
					status = customerService
							.fillCustomerDetails(customerDetails);

					if (status == true) {
						System.out
								.println("You successfully filled your Personal Details");
					} else {
						// Rollback Application
						customerService.deleteLoanApplication(applicationId);
						System.out
								.println("There was some problem in filling your Personal Details");
					}
				} else {
					System.out
							.println("There was some Problem Filling your Application Form");
				}
				break;

			case "3":
				// Input Application Id To Get your Application status
				System.out.println("Enter your Application Id");
				String applicationIdString = input.next();
				while (!loanProcessingService
						.isValidNumber(applicationIdString)) {
					System.err.println("Invalid Application Id");
					System.out.println("Enter your Application Id");
					applicationIdString = input.next();
				}
				int applicationId = Integer.parseInt(applicationIdString);

				String applicationStatusString = customerService
						.viewApplicationStatus(applicationId);
				System.out.println("Your status is : "
						+ applicationStatusString);
				break;
			case "4":
				startTheProgram();
				break;
			case "5":
				System.out.println("Have a Nice Day :-) ");
				System.exit(0);
			default:
				System.out.println("Invalid choice");
			}
			enteredAsCustomer();
		} catch (LoanProcessingException e) {
			System.err.println("Error is in :" + e.getMessage());

		}

	}

	// ================================================================
	// 2. When User has Entered As
	// Member Of Approval Department
	// ================================================================
	private static void enteredAsMemberOfBoard() {
		System.out
				.println("############################# Welcome Member Of Loan Approval Department #############################");
		System.out
				.println("#                                                                                                    #");
		System.out
				.println("#                        ----Select Options from Given menu----                                      #");
		System.out
				.println("#                        1. View all Loan Programs                                                   #");
		System.out
				.println("#                        2. View All loan Applications for specific loan program                     #");
		System.out
				.println("#                        3. Update Status of Loan Application                                        #");
		System.out
				.println("#                        4. Previous Page                                                            #");
		System.out
				.println("#                        5. Exit                                                                     #");
		System.out
				.println("#                                                                                                    #");
		System.out
				.println("######################################################################################################");
		try {
			ladService = new LoanApprovalDeptServiceImpl();
			loanProcessingService = new LoanProcessingServiceImpl();
			String ladchoice = input.next();
			switch (ladchoice) {
			case "1":
				if (displayLoanPrograms()) {
					System.out.println("No Record Found");
				}
				break;
			case "2":
				// Input a Loan Program to display all Loan Applications related
				// to that Program
				System.out.println("Enter a Loan Program");
				String loanProgram = inputString.nextLine();
				while (!loanProcessingService.isValidString(loanProgram)) {
					System.err
							.println("Should contain a minimum of 5 Characters");
					System.out.println("Enter Loan Program Name");
					loanProgram = input.next();
				}

				if (displayLoanApplication(loanProgram)) {
					System.err.println("No Record Found");
				}

				break;
			case "3":
				// Input Application Id To Get Application Status
				System.out
						.println("Enter a application id to update application status");
				String applicationIdString = input.next();
				while (!loanProcessingService
						.isValidNumber(applicationIdString)) {
					System.err.println("Invalid Application Id");
					System.out.println("Enter your Application Id");
					applicationIdString = input.next();
				}
				int applicationId = Integer.parseInt(applicationIdString);

				// Select Application Status
				System.out.println("Select new status");
				System.out.println("1. Accepted");
				System.out.println("2. Approved");
				System.out.println("3. Rejected");
				String statusChoice = input.next();
				String newStatus = null;
				switch (statusChoice) {
				case "1":
					newStatus = "Accepted";
					break;
				case "2":
					newStatus = "Approved";
					break;
				case "3":
					newStatus = "Rejected";
					break;
				default:
					System.out.println("Invalid choice");
					enteredAsMemberOfBoard();
				}

				boolean isStatusUpdated = ladService.modifyApplicationStatus(
						applicationId, newStatus);
				if (isStatusUpdated == true) {
					System.out.println("Application status for application id "
							+ applicationId + " was successfully updated");

					// If Status Is changed to Approved fill And Generate
					// Approved Loan Details
					if (newStatus == "Approved") {
						int applicationID = applicationId;

						// Get Applicant Name From Customer_Details Table
						String applicantName = ladService
								.getApplicantName(applicationId);

						// Get Loan Amount Granted From Loan_Application Table
						double loanAmountGranted = ladService
								.getLoanAmountGranted(applicationId);

						// Get Loan Time Period in Years From
						// Loan_Programs_Offered Table
						int yearsTimePeriod = ladService
								.getLoanDurationInYears(applicationId);

						// Get Rate Of Interest From Loan_Programs_Offered Table
						double rateOfInterest = ladService
								.getRateOfInterest(applicationId);

						// Calculate Monthly Installments
						double monthlyInstallments = (Math
								.pow(loanAmountGranted * rateOfInterest
										* (1 + rateOfInterest), yearsTimePeriod) / (Math
								.pow(1 + rateOfInterest, yearsTimePeriod - 1)));
						// Formula Used[P x R x (1+R)^N]/[(1+R)^N-1]

						// Calculate DownPayment for loan
						double downPayment = loanAmountGranted / 10;

						// Calculate Total Payable Loan
						double totalAmountPayable = (monthlyInstallments * 12 * yearsTimePeriod)
								+ downPayment;

						ApprovedLoanBean approvedLoan = new ApprovedLoanBean(
								applicationID, applicantName,
								loanAmountGranted, monthlyInstallments,
								yearsTimePeriod, downPayment, rateOfInterest,
								totalAmountPayable);

						boolean isCustomerAdded = ladService
								.fillApprovedLoanDetails(approvedLoan);
						if (isCustomerAdded) {
							System.out
									.println("Loan is successfully Approved for Application ID : "
											+ applicationId);
						} else {
							System.err
									.println("There was Some problem in approving loan for Application Id : "
											+ applicationId);
						}

					}
				} else {
					System.err
							.println("There was a problem in updating application status");
				}
				break;
			case "4":
				startTheProgram();
				break;
			case "5":
				System.out.println("Have a Nice Day :-) ");
				System.exit(0);

			default:
				System.err.println("Invalid choice");
			}
			enteredAsMemberOfBoard();
		} catch (LoanProcessingException e) {
			System.err.println("Error is in :" + e.getMessage());
		}
	}

	// Display Loan Application For Specific Loan Program
	public static boolean displayLoanApplication(String loanProgram)
			throws LoanProcessingException {
		boolean checkIfListIsEmpty = false;
		ArrayList<LoanApplicationBean> loanApplicationList = null;
		try {
			loanApplicationList = ladService
					.viewLoanApplicationForSpecificProgram(loanProgram);

			if (loanApplicationList.isEmpty()) {

				checkIfListIsEmpty = true;
			} else {

				for (LoanApplicationBean loanApplication : loanApplicationList) {
					System.out.println(loanApplication);
				}
			}
		} catch (LoanProcessingException e) {
			System.err.println("Error is " + e.getMessage());
		}
		return checkIfListIsEmpty;
	}

	// ================================================================
	// 3. When User has Entered As a Admin
	// ================================================================

	private static void enteredAsAdmin() {
		System.out
				.println("############################ Welcome Admin ####################################");
		System.out
				.println("#                                                                             #");

		System.out
				.println("#              ---Slect Options from menu--                                   #");
		System.out
				.println("#              1. View all Loan Programs                                      #");
		System.out
				.println("#              2. Update Loan Program                                         #");
		System.out
				.println("#              3. View List of Loan Applications Approved/Accepted            #");
		System.out
				.println("#              4. Previous Page                                               #");
		System.out
				.println("#              5. Exit                                                        #");
		System.out
				.println("#                                                                             #");
		System.out
				.println("###############################################################################");
		try {
			adminService = new AdminServiceImpl();
			ladService = new LoanApprovalDeptServiceImpl();
			loanProcessingService = new LoanProcessingServiceImpl();
			String adminChoice = input.next();
			switch (adminChoice) {
			case "1":
				if (displayLoanPrograms()) {
					System.out.println("No Record Found");
				}
				break;
			case "2":
				System.out.println("Select option :-");
				System.out.println("1. Add a Loan Program");
				System.out.println("2. Delete a Loan Program");
				String loanProgramUpdateChoice = input.next();
				switch (loanProgramUpdateChoice) {
				case "1":

					// Input Loan Program
					System.out.println("Enter Loan Program Name");
					String loanProgramString = input.next();
					while (!loanProcessingService
							.isValidString(loanProgramString)) {
						System.err
								.println("Should contain a minimum of 5 Characters");
						System.out.println("Enter Loan Program Name");
						loanProgramString = input.next();
					}

					// Input Loan Program Description
					System.out.println("Enter Loan Program Description");
					String description = inputString.nextLine();
					while (!loanProcessingService
							.isValidLoanProgramDescription(description)) {
						System.err
								.println("Loan Program Description  should not be more than 20 characters");
						System.out.println("Enter Loan Program Description");
						description = inputString.nextLine();
					}

					// Input Loan Type
					System.out.println("Specify Loan type");
					String loanType = input.next();
					while (!loanProcessingService.isValidLoanType(loanType)) {
						System.err.println("Not a Valid Loan Type");
						System.out.println("Specify Loan type");
						loanType = input.next();
					}

					// Input Loan Program Duration in Years
					System.out.println("Loan Program duration in years");
					String durationInYearsString = input.next();
					while (!loanProcessingService
							.isValidNumber(durationInYearsString)) {
						System.err.println("Invalid Loan Duration in Years");
						System.out.println("Loan Program duration in years");
						durationInYearsString = input.next();
					}
					int durationInYears = Integer
							.parseInt(durationInYearsString);

					// Input Minimum Loan Amount
					System.out.println("Minimum Loan Amount");
					String minLoanAmntString = input.next();
					while (!loanProcessingService
							.isValidDouble(minLoanAmntString)) {
						System.err.println("Invalid amount");
						System.out.println("Minimum Loan Amount");
						minLoanAmntString = input.next();
					}
					double minLoanAmnt = Double.parseDouble(minLoanAmntString);

					// Input Maximum Loan Amount
					System.out.println("Maximum Loan Amount");
					String maxLoanAmntString = input.next();
					while (!loanProcessingService
							.isValidDouble(maxLoanAmntString)) {
						System.err.println("Invalid amount");
						System.out.println("Maximum Loan Amount");
						maxLoanAmntString = input.next();
					}
					double maxLoanAmnt = Double.parseDouble(maxLoanAmntString);

					// Input Rate Of Interest
					System.out.println("Rate of intrest on Loan");
					String rateOfIntrestString = input.next();
					while (!loanProcessingService
							.isValidDouble(rateOfIntrestString)) {
						System.err.println("Invalid amount");
						System.out.println("Rate of intrest on Loan");
						rateOfIntrestString = input.next();
					}
					double rateOfIntrest = Double
							.parseDouble(rateOfIntrestString);

					// Input Guarantee Proof Required
					System.out.println("Mention all the proofs Required");
					String proofReq = inputString.nextLine();
					while (!loanProcessingService
							.isValidGauranteeCoverString(proofReq)) {
						System.err
								.println("Proof Required details should not be more than 20 characters");
						System.out.println("Mention all the proofs Required");
						proofReq = inputString.nextLine();
					}

					LoanProgramOfferedBean newLoanProgram = new LoanProgramOfferedBean(
							loanProgramString, description, loanType,
							durationInYears, minLoanAmnt, maxLoanAmnt,
							rateOfIntrest, proofReq);

					boolean isLoanProgramAdded = adminService
							.addLoanProgram(newLoanProgram);
					if (isLoanProgramAdded) {
						System.out.println("Loan Program Added Successfully");
					} else {
						System.out
								.println("There was Some Problem in Adding Loan Program");
					}
					break;
				case "2":
					System.out.println("Enter Loan Program name to be Deleted");
					String loanProgram = inputString.nextLine();
					while (!loanProcessingService.isValidString(loanProgram)) {
						System.err
								.println("Should contain a minimum of 5 Characters");
						System.out.println("Enter Loan Program Name");
						loanProgram = input.next();
					}

					if (isLoanProgramAlreadyExisting(loanProgram)) {
						System.out
								.println("This Loan Program Cannot be deleted as it exists in Loan Application table");
					} else {
						boolean isLoanProgramDeleted = adminService
								.deleteLoanProgram(loanProgram);
						if (isLoanProgramDeleted) {
							System.out
									.println("Loan Program Deleted Successfully");
						} else {
							System.err
									.println("There was some Problem in deleting Loan Program");
						}

					}

					break;
				default:
					System.out.println("Invalid Choice ");
					enteredAsAdmin();
				}
				break;
			case "3":
				System.out
						.println("1. View Loan Applications for Accepted Loan");
				System.out
						.println("2. View Loan Applicatoins for Approved Loan");
				ArrayList<LoanApplicationBean> loanApplicationList = null;
				String loanApplicationStatus = null;
				String loanApplicationStatusChoice = input.next();
				switch (loanApplicationStatusChoice) {
				case "1":
					loanApplicationStatus = "Accepted";
					break;
				case "2":
					loanApplicationStatus = "Approved";
					break;
				default:
					System.out.println("Invalid Choice ");
					enteredAsAdmin();
				}
				loanApplicationList = adminService
						.viewLoanApplicationForSpecificStatus(loanApplicationStatus);
				if (loanApplicationList.isEmpty()) {
					System.out.println("No Record Found");
				} else {
					for (LoanApplicationBean loanApplication : loanApplicationList) {
						System.out.println(loanApplication);
					}
				}
				break;
			case "4":
				startTheProgram();
			case "5":
				System.out.println("Have a Nice Day :-) ");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice ");
				enteredAsAdmin();

			}
			enteredAsAdmin();
		} catch (Exception e) {
			System.err.println("Error is in :" + e.getMessage());

		}

	}

	// METHOD TO CHECK IF LOAN PROGRAM IS EXISTING IN LOAN APPLICATION TABLE
	public static boolean isLoanProgramAlreadyExisting(String loanProgram)
			throws LoanProcessingException {
		ArrayList<LoanApplicationBean> loanApplicationList = null;
		try {
			loanApplicationList = ladService
					.viewLoanApplicationForSpecificProgram(loanProgram);

			if (loanApplicationList.isEmpty()) {

				return false;
			}

		} catch (LoanProcessingException e) {
			System.err.println("Error is " + e.getMessage());
		}
		return true;

	}

	// ================================================================
	// 4. Common methods
	// ================================================================
	private static boolean displayLoanPrograms() throws LoanProcessingException {
		boolean checkIfListIsEmpty = false;
		ArrayList<LoanProgramOfferedBean> loanProgramList = null;
		loanProcessingService = new LoanProcessingServiceImpl();
		try {
			loanProgramList = loanProcessingService.viewLoanProgramsOffered();
			if (loanProgramList.isEmpty()) {
				checkIfListIsEmpty = true;
			} else {
				for (LoanProgramOfferedBean loanProgram : loanProgramList) {
					System.out.println(loanProgram);
				}
			}
		} catch (LoanProcessingException e) {
			System.err.println("Error is " + e.getMessage());
		}

		return checkIfListIsEmpty;
	}
}
