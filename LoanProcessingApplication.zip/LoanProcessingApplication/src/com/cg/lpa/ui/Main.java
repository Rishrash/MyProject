package com.cg.lpa.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.lpa.bean.LoanApplicationBean;
import com.cg.lpa.bean.LoanProgramOfferedBean;
import com.cg.lpa.service.CustomerServiceImpl;
import com.cg.lpa.service.ICustomerService;
import com.cg.lpa.service.ILoanApprovalDeptService;
import com.cg.lpa.service.ILoanProcessingService;
import com.cg.lpa.service.LoanApprovalDeptServiceImpl;
import com.cg.lpa.service.LoanProcessingServiceImpl;
import com.cg.lpa.test.LoanProcessingException;

public class Main {
	private static Scanner input;
	private static Scanner inputString;

	static ILoanProcessingService loanProcessingService = null;
	static ICustomerService customerService = null;
	static ILoanApprovalDeptService ladService = null;

	// MAIN METHOD
	public static void main(String[] args) throws LoanProcessingException {

		input = new Scanner(System.in);
		inputString = new Scanner(System.in);

		startTheProgram();
	}

	// START METHOD

	private static void startTheProgram() throws LoanProcessingException {

		System.out.println("Welcome To Loan Processing Application\n\n");
		System.out.println("Select your role from below :");
		System.out.println("1. Enter as a Customer");
		System.out
				.println("2. Login as Member Of Approval Department or Admin");
		System.out.println("3. Exit");

		int userInput = input.nextInt();

		switch (userInput) {
		case 1:
			enteredAsCustomer();
			break;
		case 2:
			loginUser();
			break;
		case 3:
			System.out.println("Have a great day!");
			System.exit(0);
		}
		startTheProgram();
	}

	// LOGIN METHOD

	private static void loginUser() throws LoanProcessingException {
		loanProcessingService = new LoanProcessingServiceImpl();
		input = new Scanner(System.in);
		System.out.print("UserId : ");
		String userId = input.next();
		System.out.print("Password : ");
		String password = input.next();

		try {
			if (loanProcessingService.loginUser(userId, password) == 0) {
				// Enter As Member of Loan Approval Board
				enteredAsMemberOfBoard();

			} else if (loanProcessingService.loginUser(userId, password) == 1) {
				// Enter As Admin
				enteredAsAdmin();

			} else {
				// Incorrect Password
				System.out.println("Password is wrong");

			}
		} catch (LoanProcessingException e) {

			throw new LoanProcessingException("problem : " + e.getMessage());
		}

	}

	// ================================================================
	// = =
	// = 1. When User has Entered As a Customer
	// =
	// ================================================================

	private static void enteredAsCustomer() {
		System.out.println("Welcome Customer");
		System.out.println("Select Options from Given menu");
		System.out.println("1. View all Loan Programs");
		System.out.println("2. Apply for a new loan");
		System.out
				.println("3. View Application status of your Loan Application");
		System.out.println("4. Previous Page");
		System.out.println("5. Exit");
		try {

			int customerChoice = input.nextInt();
			customerService = new CustomerServiceImpl();
			switch (customerChoice) {

			// View loan Programs
			case 1:
				if (displayLoanPrograms()) {
					System.out.println("No Record Found");
				}
				break;
			case 2:

				System.out.println("Fill Loan Application Form:");

				System.out.println("Enter Loan Program Name");
				String loanProgram = input.next();

				System.out.println("Enter Loan Amount");
				double loanAmount = input.nextDouble();

				System.out.println("Enter your Property Address");
				String propertyAddress = inputString.nextLine();

				System.out.println("Enter Annual Family Income");
				double annualFamilyIncome = input.nextDouble();

				System.out.println("Docs Proof to be diplayed");
				String docsProof = inputString.nextLine();

				System.out.println("Guarantee Cover Details ");
				String guaranteeCover = inputString.nextLine();

				System.out.println("Market Value Of your Guarantee Cover");
				double marktValOfCover = input.nextDouble();

				LoanApplicationBean loanApplication = new LoanApplicationBean(
						loanProgram, loanAmount, propertyAddress,
						annualFamilyIncome, docsProof, guaranteeCover,
						marktValOfCover);

				boolean status = customerService.applyLoan(loanApplication);

				System.out.println("Please Fill your Personal Details");

				customerService.applyLoan(loanApplication);
				break;
			case 3:
				customerService.viewApplicationStatus();
				break;
			case 4:
				startTheProgram();
				break;
			case 5:
				System.exit(0);
				break;
			}
			enteredAsCustomer();
		} catch (InputMismatchException e) {
			System.err.println("Error is in :" + e.getMessage());
		} catch (Exception e) {
			System.err.println("Error is in :" + e.getMessage());
		}

	}

	// ================================================================
	// =
	// = 2. When User has Entered As
	// = ...Member Of Approval Department
	// =
	// ================================================================
	private static void enteredAsMemberOfBoard() {
		System.out.println("Welcome Member Of Loan Approval Department");
		ladService = new LoanApprovalDeptServiceImpl();
		int ladchoice = input.nextInt();
		switch (ladchoice) {

		}
	}

	// ================================================================
	// =
	// =3. When User has Entered As a Admin
	// =
	// ================================================================

	private static void enteredAsAdmin() {
		System.out.println("Welcome Admin");
	}

	// ================================================================
	// = =
	// = 3. Common methods =
	// = =
	// ================================================================
	private static boolean displayLoanPrograms() throws ClassNotFoundException,
			SQLException {
		boolean checkIfListIsEmpty = false;
		ArrayList<LoanProgramOfferedBean> loanProgramList = null;
		loanProcessingService = new LoanProcessingServiceImpl();
		try {
			loanProgramList = loanProcessingService.viewLoanProgramsOffered();
			if (loanProgramList.isEmpty()) {
				checkIfListIsEmpty = true;
			} else {
				for (LoanProgramOfferedBean loanProgram : loanProgramList) {
					System.out.println(loanProgram);
				}
			}
		} catch (LoanProcessingException e) {
			System.err.println("Error is " + e.getMessage());
		}

		return checkIfListIsEmpty;
	}
}
