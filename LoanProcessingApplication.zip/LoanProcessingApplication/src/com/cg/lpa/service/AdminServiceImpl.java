package com.cg.lpa.service;

public class AdminServiceImpl {

}
