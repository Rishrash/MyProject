package com.cg.lpa.service;

import java.util.ArrayList;

import com.cg.lpa.bean.LoanApplicationBean;

public class LoanApprovalDeptServiceImpl implements ILoanApprovalDeptService {

	@Override
	public ArrayList<LoanApplicationBean> viewLoanApplicationForSpecificProgram(String loanProgram) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean modifyApplicationStatus(LoanApplicationBean loanapplication) {
		// TODO Auto-generated method stub
		return false;
	}

}
