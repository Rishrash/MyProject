package com.cg.lpa.service;

public interface IAdminService {
	/*
	 * TODO : Update Info Of Long Program TODO : View List of loan applications
	 * approved/accepted (waiting for interview)/rejected for a loan program.
	 */

}
