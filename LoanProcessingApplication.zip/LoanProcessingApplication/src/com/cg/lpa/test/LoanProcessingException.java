package com.cg.lpa.test;

public class LoanProcessingException extends Exception {
	public LoanProcessingException(String message) {
		super(message);
	}

	public LoanProcessingException() {

	}

}
