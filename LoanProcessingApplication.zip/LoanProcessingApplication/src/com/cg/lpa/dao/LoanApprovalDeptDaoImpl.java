package com.cg.lpa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.lpa.bean.LoanApplicationBean;
import com.cg.lpa.dbutil.DBUtil;
import com.cg.lpa.test.LoanProcessingException;

public class LoanApprovalDeptDaoImpl implements ILoanApprovalDeptDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet RSAKey = null;

	@Override
	public ArrayList<LoanApplicationBean> viewLoanApplicationForSpecificProgram(
			String loanProgram) throws LoanProcessingException {
		try {
			conn = DBUtil.establishConnection();
			pstmt = conn
					.prepareStatement("SELECT * FROM loan_application WHERE loan_program = ");
		} catch (SQLException e) {
			throw new LoanProcessingException("Error in " + e.getMessage());
		}

		return null;
	}

	@Override
	public boolean modifyApplicationStatus(LoanApplicationBean loanapplication)
			throws LoanProcessingException {

		return false;
	}

}
