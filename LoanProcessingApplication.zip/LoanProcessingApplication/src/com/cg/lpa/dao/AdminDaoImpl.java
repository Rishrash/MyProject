package com.cg.lpa.dao;

public class AdminDaoImpl {

}
