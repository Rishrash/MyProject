package com.cg.lpa.dao;

public interface IAdminDao {

}
